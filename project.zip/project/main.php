<?php
session_start();
$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Page</title>
</head>
<body>
    <center>
        <h1>Bienvenue <?php echo $username; ?>!</h1>
        <hr>
        <p>Ceci est la page principale.</p>
        <p><a href="LoginPage.php">Déconnexion</a></p>
    </center>
</body>
</html>
