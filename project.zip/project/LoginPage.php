<?php
session_start();
include 'database.php';
 
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $name =$_POST["Name"];
    $password =$_POST["Password"];

    $query = "SELECT * FROM Login WHERE username = $name AND password = $password";
    $result = mysqli_query($conn,$query);

    if ($result->num_rows > 0) {

        $_SESSION['username'] = $name;
        header("Location: main.php");
        exit;
    } else {
        $error = "Nom d'utilisateur ou mot de passe incorrect";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LoginPage</title>
</head>
<body>
    <center>
        <h1>Login</h1>
        <hr>
        <form method="post" action="LoginPage.php">
            <label for="Name">Name</label><br>
            <input type="text" name="Name" id="Name" required><br><br>
            <label for="Password">Password</label><br>
            <input type="password" name="Password" id="Password" required><br><br>
            <hr>
            <input type="submit">
            <br><br>
            <?php
            if(isset($error)) {
                echo "<span style='color:red;'>$error</span>";
            }
            ?>
        </form>
    </center>
</body>
</html>
